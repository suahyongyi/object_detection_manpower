# staff_customer_annotation > dataset_resized_v2
https://universe.roboflow.com/iti121deeplearning/staff_customer_annotation

Provided by a Roboflow user
License: CC BY 4.0

